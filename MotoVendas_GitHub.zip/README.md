# MotoVendas — projeto escolar

Site simples de venda de motos feito com HTML, CSS e JavaScript.

## Como publicar no GitHub Pages

1. Crie um repositório no GitHub.
2. Envie `index.html`, `style.css` e `script.js`.
3. No repositório, abra **Settings → Pages**.
4. Em **Build and deployment**, escolha **Deploy from a branch**.
5. Selecione a branch `main` e a pasta `/ (root)`.
6. Salve e aguarde o GitHub gerar o endereço do site.

## Personalização

- Em `script.js`, altere o número do WhatsApp.
- Em `index.html`, troque o nome da loja e os textos.
- No mesmo arquivo JS, altere nomes e preços das motos.

Os preços deste projeto são apenas exemplos para fins escolares.
