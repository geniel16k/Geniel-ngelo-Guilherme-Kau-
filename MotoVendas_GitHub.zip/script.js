const motos = [
  { nome: "Honda CG 160", categoria: "urbana", ano: 2026, km: "0 km", preco: 18990 },
  { nome: "Yamaha Factor 150", categoria: "urbana", ano: 2026, km: "0 km", preco: 17990 },
  { nome: "Honda CB 300F", categoria: "street", ano: 2026, km: "0 km", preco: 24990 },
  { nome: "Yamaha Fazer 250", categoria: "street", ano: 2025, km: "8.400 km", preco: 21890 },
  { nome: "Honda XRE 300", categoria: "trail", ano: 2025, km: "5.900 km", preco: 29990 },
  { nome: "Yamaha MT-03", categoria: "esportiva", ano: 2025, km: "3.200 km", preco: 31990 }
];

const list = document.querySelector("#bike-list");
const search = document.querySelector("#search");
const category = document.querySelector("#category");
const empty = document.querySelector("#empty-state");

function money(value) {
  return value.toLocaleString("pt-BR", { style: "currency", currency: "BRL" });
}

function labelCategory(value) {
  const labels = {
    urbana: "Urbana",
    street: "Street",
    trail: "Trail",
    esportiva: "Esportiva"
  };
  return labels[value] || value;
}

function render() {
  const q = search.value.trim().toLowerCase();
  const cat = category.value;

  const filtered = motos.filter(moto => {
    const matchName = moto.nome.toLowerCase().includes(q);
    const matchCat = cat === "todos" || moto.categoria === cat;
    return matchName && matchCat;
  });

  list.innerHTML = filtered.map(moto => `
    <article class="bike-card">
      <div class="bike-image" aria-hidden="true">🏍️</div>
      <div class="bike-body">
        <span class="category">${labelCategory(moto.categoria)}</span>
        <h3>${moto.nome}</h3>
        <div class="meta">${moto.ano} • ${moto.km}</div>
        <div class="price">${money(moto.preco)} <small>à vista</small></div>
        <div class="card-actions">
          <a class="btn btn-primary" target="_blank" rel="noopener"
             href="https://wa.me/5500000000000?text=Olá!%20Tenho%20interesse%20na%20${encodeURIComponent(moto.nome)}.">
             Tenho interesse
          </a>
        </div>
      </div>
    </article>
  `).join("");

  empty.hidden = filtered.length !== 0;
}

search.addEventListener("input", render);
category.addEventListener("change", render);

const menuBtn = document.querySelector(".menu-btn");
const nav = document.querySelector("nav");

menuBtn.addEventListener("click", () => {
  const open = nav.classList.toggle("open");
  menuBtn.setAttribute("aria-expanded", open);
});

document.querySelectorAll("nav a").forEach(link => {
  link.addEventListener("click", () => {
    nav.classList.remove("open");
    menuBtn.setAttribute("aria-expanded", "false");
  });
});

// Troque este número pelo WhatsApp da loja/projeto.
document.querySelector("#whatsappLink").href =
  "https://wa.me/5500000000000?text=Olá!%20Vim%20pelo%20site%20MotoVendas.";

render();
